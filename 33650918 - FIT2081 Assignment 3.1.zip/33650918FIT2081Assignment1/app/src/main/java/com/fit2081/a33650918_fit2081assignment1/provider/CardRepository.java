package com.fit2081.a33650918_fit2081assignment1.provider;

import android.app.Application;
import androidx.lifecycle.LiveData;

import java.util.List;

public class CardRepository {

    // private class variable to hold reference to DAO
    private CardDAO cardDAO;
    // private class variable to temporary hold all the items retrieved and pass outside of this class
    private LiveData<List<Categories>> allCategoriesLiveData;
    private LiveData<List<Events>> allEventsLiveData;

    // constructor to initialise the repository class
    CardRepository(Application application) {
        // get reference/instance of the database
        CardDatabase db = CardDatabase.getDatabase(application);

        // get reference to DAO, to perform CRUD operations
        cardDAO = db.cardDAO();

        // once the class is initialised get all the items in the form of LiveData
        allCategoriesLiveData = cardDAO.getAllCategories();
        allEventsLiveData = cardDAO.getAllEvents();
    }

    /**
     * Repository method to get all cards
     * @return LiveData of type List<Categories>
     */
    LiveData<List<Categories>> getAllCategories() {
        return allCategoriesLiveData;
    }

    void insertCategory(Categories categories) {
        // Executes the database operation to insert the item in a background thread.
        CardDatabase.databaseWriteExecutor.execute(() -> cardDAO.addCategory(categories));
    }

    void deleteAllCategories() {
        CardDatabase.databaseWriteExecutor.execute(() -> cardDAO.deleteAllCategories());
    }


    LiveData<List<Events>> getAllEvents() {
        return allEventsLiveData;
    }

    /**
     * Repository method to insert one single item
     * @param events object containing details of new Categories to be inserted
     */

    void insertEvent(Events events) {
        // Executes the database operation to insert the item in a background thread.
        CardDatabase.databaseWriteExecutor.execute(() -> cardDAO.addEvent(events));
    }

    void deleteAllEvents() {
        CardDatabase.databaseWriteExecutor.execute(() -> cardDAO.deleteAllEvents());
    }
}

