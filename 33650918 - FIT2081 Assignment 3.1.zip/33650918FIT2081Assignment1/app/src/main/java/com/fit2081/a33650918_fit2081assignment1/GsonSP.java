package com.fit2081.a33650918_fit2081assignment1;

import android.content.SharedPreferences;
import android.content.Context;

import com.fit2081.a33650918_fit2081assignment1.provider.Categories;
import com.fit2081.a33650918_fit2081assignment1.provider.Events;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class GsonSP {

    public static void saveCategoryListInSharedPreference(Context context, String category_key, ArrayList<Categories> list){
        Gson gson = new Gson();
        String gsonString = gson.toJson(list);
        SharedPreferences.Editor editor = context.getSharedPreferences("show_recycler", Context.MODE_PRIVATE).edit();
        editor.putString(category_key, gsonString);
        editor.apply();
    }

    public static void saveEventListInSharedPreference(Context context, String event_key, ArrayList<Events> list){
        Gson gson = new Gson();
        String gsonString = gson.toJson(list);
        SharedPreferences.Editor editor = context.getSharedPreferences("show_recycler", Context.MODE_PRIVATE).edit();
        editor.putString(event_key, gsonString);
        editor.apply();
    }

    public static ArrayList<Categories> addCategoryToRecyclerView(Context context, String category_key){
        Gson gson = new Gson();
        SharedPreferences sharedPreferences = context.getSharedPreferences("show_recycler", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("CATEGORY KEY", String.valueOf(new ArrayList<Categories>()));
        Type type = new TypeToken<ArrayList<Categories>>() {}.getType();
        return gson.fromJson(json,type);
    }

    public static ArrayList<Events> addEventToRecyclerView(Context context, String event_key){
        Gson gson = new Gson();
        SharedPreferences sharedPreferences = context.getSharedPreferences("show_recycler", Context.MODE_PRIVATE);
        String json = sharedPreferences.getString("EVENTS KEY", String.valueOf(new ArrayList<Categories>()));
        Type type = new TypeToken<ArrayList<Events>>() {}.getType();
        return gson.fromJson(json,type);
    }
}
