package com.fit2081.a33650918_fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // declare constants for SharedPreferences key
    public final static String USERNAME_KEY = "username_key";
    public final static String PASSWORD_KEY = "password_key";

    EditText editUsername;
    EditText editPassword;
    EditText editConfirmPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get reference from the user input
        editUsername = findViewById(R.id.editUsername0);
        editPassword = findViewById(R.id.editPassword0);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);
    }

    // when the register button is clicked
    public void onBtnRegisterClick(View view) {
        // change the user input into string
        String getUsernameString = editUsername.getText().toString();
        String getPasswordString = editPassword.getText().toString();
        String getConfirmPasswordString = editConfirmPassword.getText().toString();

        // check to see if there is username input, and password has the same value as confirm password
        if (getUsernameString.length()>0 && getPasswordString.equals(getConfirmPasswordString) && getPasswordString.length() > 0) {
            // toast message for successful registration
            String customMessage = String.format("Hi %s, you have registered successfully!", getUsernameString);
            Toast.makeText(this, customMessage, Toast.LENGTH_SHORT).show();

            // save the username and password data to the storage
            saveMyData(getUsernameString, getPasswordString);

            // direct to the next page if password matches
            Intent intent = new Intent(this, loginPage.class);
            startActivity(intent);

            // if there is no password
        } else if (getUsernameString.length() == 0) {
            String noUsernameMessage = "Please enter username.";
            Toast.makeText(this, noUsernameMessage, Toast.LENGTH_SHORT).show();

        } else if (getPasswordString.length() == 0) {
            String noPasswordMessage = "Please enter a password.";
            Toast.makeText(this, noPasswordMessage, Toast.LENGTH_SHORT).show();

            // if there is no username
        } else {
            // toast message for when the password and confirm password doesn't match
            String falseMessage = String.format("Hi %s, password do not match. Please try again.", getUsernameString);
            Toast.makeText(this, falseMessage, Toast.LENGTH_SHORT).show();
        }

        // remove all the current values and set it empty by declaring ""
        editUsername.setText("");
        editPassword.setText("");
        editConfirmPassword.setText("");
    }

    // when the cancel button is clicked
    public void onBtnCancelClick(View view) {
        EditText editUsername;
        EditText editPassword;
        EditText editConfirmPassword;

        // get reference from the user input
        editUsername = findViewById(R.id.editUsername0);
        editPassword = findViewById(R.id.editPassword0);
        editConfirmPassword = findViewById(R.id.editConfirmPassword);

        // set the values to "" when the cancel button is clicked
        editUsername.setText("");
        editPassword.setText("");
        editConfirmPassword.setText("");
    }

    private void saveMyData(String usernameValue, String passwordValue) {
        // initialise shared preference class variable to access the storage
        SharedPreferences sharedPreferences = getSharedPreferences("REGISTER_PAGE", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString(USERNAME_KEY, usernameValue);
        editor.putString(PASSWORD_KEY, passwordValue);

        // save data asynchronously without freezing the UI
        editor.apply();
    }

}