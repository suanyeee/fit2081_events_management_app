package com.fit2081.a33650918_fit2081assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import java.util.Random;
import java.util.StringTokenizer;

public class newEventForm extends AppCompatActivity {

    // declare constants for SharedPreferences key

    public static final String EVENT_ID_KEY = "eventId_key";
    public static final String EVENT_NAME_KEY = "eventName_key";
    public static final String CATEGORY_ID_KEY = "categoryId_key";
    public static final int TICKETS_AVAILABLE_KEY = 0;
    public static final boolean IS_ACTIVE_KEY = false;

    EditText editEventId;
    EditText editEventName;
    EditText editCategoryId;
    EditText editTicketsAvailability;
    Switch isActive;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // changed the layout to app_bar_layout as the activity main
        // is included as child along with the toolbar
        setContentView(R.layout.activity_new_event_form);

        // get reference from the user input
        editEventId = findViewById(R.id.editEventId);
        editEventName = findViewById(R.id.editEventName);
        editCategoryId = findViewById(R.id.editCategoryId4);
        editTicketsAvailability = findViewById(R.id.editTicketsAvailable);
        isActive = findViewById(R.id.switchIsActive4);

        sharedPreferences = getSharedPreferences("CATEGORY_FORM_PAGE", MODE_PRIVATE);

        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();
        /*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * */
        registerReceiver(myBroadCastReceiver, new IntentFilter(CategorySMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);

    }

    public void onBtnSaveEventClick(View view) {
        // change the user input into string
        String getEventId = editEventId.getText().toString();
        String getEventName = editEventName.getText().toString();
        String getCategoryId = editCategoryId.getText().toString();
        String getTicketsAvailability = editTicketsAvailability.getText().toString();
        boolean isActiveBool = isActive.isChecked();

        // if there is category name and category id given from the user
        if (getEventName.length() > 0 && getCategoryId.length() == 8 && getEventId.length() == 0) {

            // if there is user input for tickets available
            if (getTicketsAvailability.length() > 0) {
                try {
                    // try convert the event count value into integer
                    int getTicketsAvailabilityInt = Integer.parseInt(getTicketsAvailability);

                    // if the parsed value is greater than or equals to 0
                    if (getTicketsAvailabilityInt >= 0) {

                        // create instance of Random class
                        Random random = new Random();
                        char firstRandomChar = (char) (random.nextInt(26) + 'A');
                        char secondRandomChar = (char) (random.nextInt(26) + 'A');
                        String fiveRandomDigits = String.format("%05d", random.nextInt(10000));

                        // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                        String randomIdGenerator = "E" + firstRandomChar + secondRandomChar + "-" + fiveRandomDigits;

                        // assign the generated random ID to the empty event id plaintext
                        editEventId.setText(randomIdGenerator);

                        // save the randomID, event name, category id, tickets availability and switch data to the storage
                        saveMyData(randomIdGenerator, getEventName, getCategoryId, getTicketsAvailabilityInt, isActiveBool);

                        // display a toast saying data saved successfully
                        String savedEventMsg = "Event saved successfully, " + randomIdGenerator;
                        Toast.makeText(this, savedEventMsg, Toast.LENGTH_SHORT).show();

                        // if the user input a negative number for tickets available
                    } else {
                        editTicketsAvailability.setText("");
                        Toast.makeText(this, "Please insert a positive number for tickets available.", Toast.LENGTH_SHORT).show();
                    }

                    // prevent app from crashing if user input of ticket availability cannot be converted as string
                } catch (Exception e) {
                    Toast.makeText(this, "Please enter a valid ticket availability.", Toast.LENGTH_SHORT).show();
                }

                // if the user does not input any value for tickets available, assign the value 0
            } else {
                // create instance of Random class
                Random rnd = new Random();
                char firstRandomChar = (char) (rnd.nextInt(26) + 'A');
                char secondRandomChar = (char) (rnd.nextInt(26) + 'A');
                String fiveRandomDigits = String.format("%05d", rnd.nextInt(10000));

                // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                String randomIdGenerator = "C" + firstRandomChar + secondRandomChar + "-" + fiveRandomDigits;

                // assign the generated random ID to the empty event id plaintext
                editEventId.setText(randomIdGenerator);

                // save the randomID, event name, category id, tickets availability and switch data to the storage
                saveMyData(randomIdGenerator, getEventName, getCategoryId, 0, isActiveBool);

                // display a toast saying data saved successfully
                String savedEventMsg = "Event saved successfully, " + randomIdGenerator;
                Toast.makeText(this, savedEventMsg, Toast.LENGTH_SHORT).show();
            }

            // if an event id was input by the user
        } else if (getEventId.length() > 0) {

            // assign an empty value to the event id plain text
            editEventId.setText("");
            Toast.makeText(this, "Please leave the event ID empty, it is auto generated.", Toast.LENGTH_SHORT).show();

            // if no category id was given
        } else if (getCategoryId.length() == 0){
            Toast.makeText(this, "Please enter category id.", Toast.LENGTH_SHORT).show();

            // if no event name was given
        } else if (getEventName.length() == 0){
            Toast.makeText(this, "Please enter an event name", Toast.LENGTH_SHORT).show();

            // if the user did not enter a valid category id
        } else {

            // remove the ticket availability input
            editTicketsAvailability.setText("");
            Toast.makeText(this, "Please enter a valid category id.", Toast.LENGTH_SHORT).show();
        }
    }

    private void saveMyData(String eventId, String eventName, String categoryId, int ticketsAvailable, boolean isActiveOrNot) {
        // initialise shared preference class variable to access the storage
        SharedPreferences sharedPreferences = getSharedPreferences("EVENT_FORM_PAGE", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString(EVENT_ID_KEY, eventId);
        editor.putString(EVENT_NAME_KEY, eventName);
        editor.putString(CATEGORY_ID_KEY, categoryId);
        editor.putInt(String.valueOf(TICKETS_AVAILABLE_KEY), ticketsAvailable);
        editor.putBoolean(String.valueOf(IS_ACTIVE_KEY), isActiveOrNot);

        // save data asynchronously without freezing the UI
        editor.apply();
    }
    class MyBroadCastReceiver extends BroadcastReceiver {
        /*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * */
        @Override
        public void onReceive(Context context, Intent intent) {
            // Tokenize received message here
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(CategorySMSReceiver.SMS_MSG_KEY);
            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg) {
            try {
                /*
                 * String Tokenizer is used to parse the incoming message
                 * The protocol is to have the account holder name and account number separate by a semicolon
                 * */
                StringTokenizer sT = new StringTokenizer(msg, ";");
                String eventNameStr = sT.nextToken();
                String categoryIdStr = sT.nextToken();
                String ticketsAvailableStr = sT.nextToken();
                String isActiveStr = sT.nextToken();

                // if the sms input start with "event:"
                if (eventNameStr.startsWith("event:")) {
                    eventNameStr = eventNameStr.substring("event:".length()).trim();

                    editEventName.setText(eventNameStr);
                    editCategoryId.setText(categoryIdStr);
                    int ticketsAvailableInt = Integer.parseInt(ticketsAvailableStr);
                    editTicketsAvailability.setText(String.valueOf(ticketsAvailableInt));
                    isActive.setChecked(isActiveStr.equals("TRUE"));

                    // if the message input for switch is TRUE, and there is a valid category id input
                    if (isActiveStr.equals("TRUE") && categoryIdStr.length() == 8) {
                        Toast.makeText(newEventForm.this, "Message Imported Successfully.", Toast.LENGTH_SHORT).show();

                    // if the message input for switch is FALSE, and there is a valid category id input
                    } else if (isActiveStr.equals("FALSE") && categoryIdStr.length() == 8) {
                        Toast.makeText(newEventForm.this, "Message Imported Successfully.", Toast.LENGTH_SHORT).show();

                    // if there is no valid category id input
                    } else if (categoryIdStr.length() != 8) {
                        editEventName.setText("");
                        editCategoryId.setText("");
                        editTicketsAvailability.setText("");
                        isActive.setChecked(false);
                        Toast.makeText(newEventForm.this, "Please enter an appropriate category id.", Toast.LENGTH_SHORT).show();
                    }

                    // if it doesn't start with "event:", or the switch input is invalid
                } else {
                    // pass empty values due to inaccuracy
                    editEventName.setText("");
                    editCategoryId.setText("");
                    editTicketsAvailability.setText("");
                    isActive.setChecked(false);
                    Toast.makeText(newEventForm.this, "Invalid response, unable to read event form details.", Toast.LENGTH_SHORT).show();
                }

            } catch(Exception e){
                // pass empty values due to inaccuracy
                editEventName.setText("");
                editCategoryId.setText("");
                editTicketsAvailability.setText("");
                isActive.setChecked(false);
                Toast.makeText(newEventForm.this, "Invalid response, unable to read event form details.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

