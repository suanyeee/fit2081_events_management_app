package com.fit2081.a33650918_fit2081assignment1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fit2081.a33650918_fit2081assignment1.provider.Categories;

import java.util.ArrayList;
import java.util.List;

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.CustomViewHolder>{

    private ArrayList<Categories> data = new ArrayList<Categories>();

    public void setData(ArrayList<Categories> data) {
        this.data = data;
    }
    @NonNull
    @Override
    public MyRecyclerAdapter.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout, parent, false);
        MyRecyclerAdapter.CustomViewHolder viewHolder = new CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerAdapter.CustomViewHolder holder, int position) {
        holder.tvCategoryId.setText(String.valueOf(data.get(position).getCategory_id()));
        holder.tvCategoryName.setText(data.get(position).getCategory_name());
        holder.tvEventCount.setText(String.valueOf(data.get(position).getEvent_count()));
        if (data.get(position).isIs_active_cat()) {
            holder.tvIsActive.setText("Yes");
        } else {
            holder.tvIsActive.setText("No");
        }
    }

    @Override
    public int getItemCount() {
        if (this.data != null) { // if data is not null
            return this.data.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder{

        public TextView tvCategoryId;
        public TextView tvCategoryName;
        public TextView tvEventCount;
        public TextView tvIsActive;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryId = itemView.findViewById(R.id.tv_category_id);
            tvCategoryName = itemView.findViewById(R.id.tv_category_name);
            tvEventCount = itemView.findViewById(R.id.tv_event_count);
            tvIsActive = itemView.findViewById(R.id.tv_cat_is_active);
        }
    }
}
