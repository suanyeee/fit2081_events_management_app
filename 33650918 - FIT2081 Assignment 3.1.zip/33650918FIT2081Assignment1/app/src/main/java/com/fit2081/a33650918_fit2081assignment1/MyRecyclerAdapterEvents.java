package com.fit2081.a33650918_fit2081assignment1;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fit2081.a33650918_fit2081assignment1.provider.Events;

import java.util.ArrayList;

public class MyRecyclerAdapterEvents extends RecyclerView.Adapter<MyRecyclerAdapterEvents.CustomViewHolder>{

    ArrayList<Events> events_data = new ArrayList<Events>();

    public void setData(ArrayList<Events> data) {
        this.events_data = data;
    }
    @NonNull
    @Override
    public MyRecyclerAdapterEvents.CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_layout_events, parent, false);
        MyRecyclerAdapterEvents.CustomViewHolder viewHolder = new MyRecyclerAdapterEvents.CustomViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyRecyclerAdapterEvents.CustomViewHolder holder, int position) {
        holder.tvEventId.setText(String.valueOf(events_data.get(position).getEvent_id()));
        holder.tvEventName.setText(events_data.get(position).getEvent_name());
        holder.tvCategoryId.setText(events_data.get(position).getCategory_id());
        holder.tvTicketCount.setText(String.valueOf(events_data.get(position).getTickets_availability()));
        if (events_data.get(position).isIs_active_ev()) {
            holder.tvIsActiveEvents.setText("Yes");
        } else {
            holder.tvIsActiveEvents.setText("No");
        }
    }

    @Override
    public int getItemCount() {
        if (this.events_data != null) { // if data is not null
            return this.events_data.size(); // then return the size of ArrayList
        }

        // else return zero if data is null
        return 0;
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder{

        public TextView tvEventId;
        public TextView tvEventName;
        public TextView tvCategoryId;
        public TextView tvTicketCount;
        public TextView tvIsActiveEvents;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            tvEventId = itemView.findViewById(R.id.tv_category_id);
            tvEventName = itemView.findViewById(R.id.tv_category_name);
            tvCategoryId = itemView.findViewById(R.id.tv_event_count);
            tvTicketCount = itemView.findViewById(R.id.tv_cat_is_active);
            tvIsActiveEvents = itemView.findViewById(R.id.tv_event_is_active);
        }
    }
}