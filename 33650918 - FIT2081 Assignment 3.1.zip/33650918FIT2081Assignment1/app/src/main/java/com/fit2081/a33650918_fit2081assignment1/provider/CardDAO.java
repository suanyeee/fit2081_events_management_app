package com.fit2081.a33650918_fit2081assignment1.provider;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

// Indicates that this interface is a Data Access Object (DAO),
// used for interacting with the database.
@Dao
public interface CardDAO {
    // // Specifies a database query to retrieve all items from the "categories" table. (referenced A.3.4)
    @Query("select * from categories")
    LiveData<List<Categories>> getAllCategories(); // Returns a LiveData object containing a list of Categories objects.

    @Insert
    void addCategory(Categories categories); // Method signature for inserting a Categories object into the database.

    @Query("delete from categories")
    void deleteAllCategories();

/*    @Query("select * from categories where category_name=:name")
    List<Categories> getCategory(String category_name);*/

    @Query("select * from events")
    LiveData<List<Events>> getAllEvents(); // Returns a LiveData object containing a list of Categories objects.

    @Insert
    void addEvent(Events events); // Method signature for inserting a Events object into the database.


    @Query("delete from events")
    void deleteAllEvents();
}

