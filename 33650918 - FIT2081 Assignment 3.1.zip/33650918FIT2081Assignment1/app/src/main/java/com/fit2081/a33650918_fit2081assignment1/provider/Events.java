package com.fit2081.a33650918_fit2081assignment1.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "events")
public class Events {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private int id;

    @ColumnInfo(name = "columnEventId")
    private String event_id;

    @ColumnInfo(name = "columnEventName")
    private String event_name;

    @ColumnInfo(name = "columnCategoryId")
    private String category_id;

    @ColumnInfo(name = "columnTicketsAvailability")
    private int tickets_availability;

    @ColumnInfo(name = "columnIsActiveEv")
    private boolean is_active_ev;

    public Events(String event_id, String event_name, String category_id, int tickets_availability, boolean is_active_ev) {
        this.event_id = event_id;
        this.event_name = event_name;
        this.category_id = category_id;
        this.tickets_availability = tickets_availability;
        this.is_active_ev = is_active_ev;
    }

    public String getEvent_id() {
        return event_id;
    }

    public String getEvent_name() {
        return event_name;
    }

    public String getCategory_id() {
        return category_id;
    }

    public int getTickets_availability() {
        return tickets_availability;
    }

    public boolean isIs_active_ev() {
        return is_active_ev;
    }

    public int getId() {
        return id;
    }

    public void setId(@NonNull int id) {
        this.id = id;
    }
}
