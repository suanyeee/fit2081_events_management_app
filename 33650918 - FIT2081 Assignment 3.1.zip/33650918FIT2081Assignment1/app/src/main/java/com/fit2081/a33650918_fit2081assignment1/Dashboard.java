package com.fit2081.a33650918_fit2081assignment1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.fit2081.a33650918_fit2081assignment1.provider.CardViewModel;
import com.fit2081.a33650918_fit2081assignment1.provider.Categories;
import com.fit2081.a33650918_fit2081assignment1.provider.Events;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Dashboard extends AppCompatActivity {

    FragmentManager fragmentManager;
    AllCategoriesFragment allCategoriesFragment;

    // declare constants for SharedPreferences key

    public static final String EVENT_ID_KEY = "eventId_key";
    public static final String EVENT_NAME_KEY = "eventName_key";
    public static final String CATEGORY_ID_KEY = "categoryId_key";
    public static final String CATEGORY_NAME_KEY = "categoryName_key";
    public static final int EVENT_COUNT_KEY = 0;
    public static final int TICKETS_AVAILABLE_KEY = 0;
    public static final boolean IS_ACTIVE_CAT_KEY = false;
    public static final boolean IS_ACTIVE_KEY = false;

    EditText editEventId;
    EditText editEventName;
    EditText editCategoryId;
    EditText editTicketsAvailability;
    Switch isActive;
    SharedPreferences sharedPreferences;
    NavigationView navigationView;
    ArrayList<Categories> listCategories;
    Categories categories;

    Events events;
    ArrayList<Events> listEvents;

    MyRecyclerAdapter myRecyclerAdapter;

    private CardViewModel cardViewModel;


/*    MyRecyclerAdapter recyclerAdapter;
    RecyclerView recyclerView;
    RecyclerView.LayoutManager layoutManager;*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer_layout);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        DrawerLayout myDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        navigationView = findViewById(R.id.nav_view);
        MyNavigationListener myNavigationListener = new MyNavigationListener();
        navigationView.setNavigationItemSelectedListener(myNavigationListener);

        cardViewModel = new ViewModelProvider(this).get(CardViewModel.class);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, myDrawerLayout, myToolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        myDrawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onFABBtnClickSaveEvent();
                if (editEventId.length() == 9) {
                    Snackbar.make(view, "Event Saved Successfully", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                } else {
                    Snackbar.make(view, "Please try again.", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }
            }
        });


        // get reference from the user input
        editEventId = findViewById(R.id.editEventId2);
        editEventName = findViewById(R.id.editEventName2);
        editCategoryId = findViewById(R.id.editCategoryId);
        editTicketsAvailability = findViewById(R.id.editTicketsAvailable2);
        isActive = findViewById(R.id.switchIsActive2);

        sharedPreferences = getSharedPreferences("CATEGORY_FORM_PAGE", MODE_PRIVATE);

/*        ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);*/

        changeToolBarTitle("FIT2081 Assignment 2");

        fragmentManager = getSupportFragmentManager();
        allCategoriesFragment = new AllCategoriesFragment();

        listEvents = new ArrayList<>();
        // listEvents = GsonSP.addEventToRecyclerView(this, "EVENTS KEY");

        listCategories = new ArrayList<>();
        // listCategories = GsonSP.addCategoryToRecyclerView(this, "CATEGORY KEY");
    }

    public void onFABBtnClickSaveEvent() {
        // change the user input into string
        String getEventId = editEventId.getText().toString();
        String getEventName = editEventName.getText().toString();
        String getCategoryId = editCategoryId.getText().toString();
        String getTicketsAvailability = editTicketsAvailability.getText().toString();
        boolean isActiveBool = isActive.isChecked();

        // if there is category name and category id given from the user
        if (getEventName.length() > 0 && getCategoryId.length() == 8 && getEventId.length() == 0) {

            // if there is user input for tickets available
            if (getTicketsAvailability.length() > 0) {
                try {
                    // try convert the event count value into integer
                    int getTicketsAvailabilityInt = Integer.parseInt(getTicketsAvailability);

                    // if the parsed value is greater than or equals to 0
                    if (getTicketsAvailabilityInt >= 0) {

                        // SharedPreferences sharedPreferences = new getSharedPreferences(22w1);

                        // create instance of Random class
                        Random random = new Random();
                        char firstRandomChar = (char) (random.nextInt(26) + 'A');
                        char secondRandomChar = (char) (random.nextInt(26) + 'A');
                        String fiveRandomDigits = String.format("%05d", random.nextInt(10000));

                        // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                        String randomIdGenerator = "E" + firstRandomChar + secondRandomChar + "-" + fiveRandomDigits;

                        // assign the generated random ID to the empty event id plaintext
                        editEventId.setText(randomIdGenerator);

                        events = new Events(randomIdGenerator, getEventName, getCategoryId, getTicketsAvailabilityInt, isActiveBool);
                        listEvents.add(events);
                        // GsonSP.saveEventListInSharedPreference(this, "EVENTS KEY", listEvents);

                        String savedEventMsg = "Event saved successfully, " + randomIdGenerator;
                        Toast.makeText(this, savedEventMsg, Toast.LENGTH_SHORT).show();

                        Events events = new Events(randomIdGenerator, getEventName, getCategoryId, getTicketsAvailabilityInt, isActiveBool);
                        cardViewModel.insertEvents(events);

                        // if the user input a negative number for tickets available
                    } else {
                        editTicketsAvailability.setText("");
                        String positiveNumberMsg = "Please enter a positive number.";
                        Toast.makeText(this, positiveNumberMsg, Toast.LENGTH_SHORT).show();
                    }

                    // prevent app from crashing if user input of ticket availability cannot be converted as string
                } catch (Exception e) {
                    String positiveNumberMsg = "Please enter a positive number.";
                    Toast.makeText(this, positiveNumberMsg, Toast.LENGTH_SHORT).show();
                }

                // if the user does not input any value for tickets available, assign the value 0
            } else {
                // create instance of Random class
                Random rnd = new Random();
                char firstRandomChar = (char) (rnd.nextInt(26) + 'A');
                char secondRandomChar = (char) (rnd.nextInt(26) + 'A');
                String fiveRandomDigits = String.format("%05d", rnd.nextInt(10000));

                // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                String randomIdGenerator = "C" + firstRandomChar + secondRandomChar + "-" + fiveRandomDigits;

                // assign the generated random ID to the empty event id plaintext
                editEventId.setText(randomIdGenerator);

                // save the randomID, event name, category id, tickets availability and switch data to the storage
                // saveMyData(randomIdGenerator, getEventName, getCategoryId, 0, isActiveBool);

                events = new Events(randomIdGenerator, getEventName, getCategoryId, 0, isActiveBool);
                listEvents.add(events);
                // GsonSP.saveEventListInSharedPreference(this, "EVENTS KEY", listEvents);

                // display a toast saying data saved successfully
                String savedEventMsg = "Event saved successfully, " + randomIdGenerator;
                Toast.makeText(this, savedEventMsg, Toast.LENGTH_SHORT).show();

                Events events = new Events(randomIdGenerator, getEventName, getCategoryId, 0, isActiveBool);
                cardViewModel.insertEvents(events);
            }

            // if an event id was input by the user
        } else if (getEventId.length() > 0) {

            // assign an empty value to the event id plain text
            editEventId.setText("");
            String emptyEventIdMsg = "Please leave Event ID empty, it is auto-generated.";
            Toast.makeText(this, emptyEventIdMsg, Toast.LENGTH_SHORT).show();

            // if no category id was given
        } else if (getCategoryId.length() == 0){
            String noCategoryIdMsg = "Please enter a category id.";
            Toast.makeText(this, noCategoryIdMsg, Toast.LENGTH_SHORT).show();

            // if no event name was given
        } else if (getEventName.length() == 0){
            String noEventNameMsg = "Please enter an event name.";
            Toast.makeText(this, noEventNameMsg, Toast.LENGTH_SHORT).show();

            // if the user did not enter a valid category id
        } else {
            // remove the ticket availability input
            editTicketsAvailability.setText("");
            String noCategoryIdMsg = "Please enter a category id.";
            Toast.makeText(this, noCategoryIdMsg, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.option_refresh) {
            // The page will extract the category data from shared preferences, and the page refreshes
            finish();
            startActivity(getIntent());

        } else if (item.getItemId() == R.id.option_clear_event_form) {
            // Clear the items in the event form will be cleared  + add code
            editEventId.setText("");
            editEventName.setText("");
            editCategoryId.setText("");
            editTicketsAvailability.setText("");
            isActive.setChecked(false);

        } else if (item.getItemId() == R.id.option_delete_all_categories) {
            // Delete all the categories stored + add code
            deleteAllCategories();
            // clearFields();
        } else if (item.getItemId() == R.id.option_delete_all_events) {
            // Delete all the events stored + add code
            deleteAllEvents();
            // clearFields();
        }
        return true;
    }

    class MyNavigationListener implements NavigationView.OnNavigationItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            // get the id of the selected item
            int id = item.getItemId();

            if (id == R.id.nav_view_all_categories) {
                // Go to the Category Page
                goToAllCategories();
            } else if (id == R.id.nav_add_category) {
                // Do something
                goToNewCategoryForm();
            } else if (id == R.id.nav_view_all_events) {
                // Go to the Events Page
                goToAllEvents();
            } else if (id == R.id.nav_logout) {
                // Logging out of the app
                goToLoginPage();
                finish();
            }
            // close the drawer
            // myDrawerLayout.closeDrawers();
            // tell the OS
            return true;
        }
    }

    // directs the user to all the categories page
    public void goToAllCategories() {
        startActivity(new Intent(this, AllCategories.class));
    }

    // directs the user to all the events page
    public void goToAllEvents() {
        startActivity(new Intent(this, AllEvents.class));
    }

    // directs the user to the Login Page
    public void goToLoginPage() {
        startActivity(new Intent(this, loginPage.class));
    }

    public void goToNewCategoryForm() {
        startActivity(new Intent(this, newCategoryForm.class));
    }

    // clears all the data in the Category Fragment + add code
    public void deleteAllCategories() {
/*        listCategories.clear();
        GsonSP.saveCategoryListInSharedPreference(this, "CATEGORY KEY", listCategories);
        startActivity(new Intent(this, AllCategories.class));*/
        cardViewModel.deleteCategory();
    }

    public void deleteAllEvents() {
        /*listEvents.clear();
        GsonSP.saveEventListInSharedPreference(this, "EVENTS KEY", listEvents);
        startActivity(new Intent(this, AllEvents.class));*/
        cardViewModel.deleteEvents();
    }

    // clears all the data in the Events Fragment + add code
    // Not done

    private void saveMyData(String eventId, String eventName, String categoryId, int ticketsAvailable, boolean isActiveOrNot) {
        // initialise shared preference class variable to access the storage
        SharedPreferences sharedPreferences = getSharedPreferences("REGISTER_PAGE", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString(EVENT_ID_KEY, eventId);
        editor.putString(EVENT_NAME_KEY, eventName);
        editor.putString(CATEGORY_ID_KEY, categoryId);
        editor.putInt(String.valueOf(TICKETS_AVAILABLE_KEY), ticketsAvailable);
        editor.putBoolean(String.valueOf(IS_ACTIVE_KEY), isActiveOrNot);

        // save data asynchronously without freezing the UI
        editor.apply();
    }

    public void changeToolBarTitle(String title) {
        getSupportActionBar().setTitle(title);
    }
}