package com.fit2081.a33650918_fit2081assignment1;

import static com.fit2081.a33650918_fit2081assignment1.MainActivity.PASSWORD_KEY;
import static com.fit2081.a33650918_fit2081assignment1.MainActivity.USERNAME_KEY;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class loginPage extends AppCompatActivity {

    EditText editUsername;
    EditText editPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        // get reference from the user input
        editUsername = findViewById(R.id.editUsername1);
        editPassword = findViewById(R.id.editPassword1);
    }

    // when the login button was clicked
    public void onBtnLoginClick(View view) {
        // change the user input into string
        String getLoginUsername = editUsername.getText().toString();
        String getLoginPassword = editPassword.getText().toString();

        // initialise shared preference class variable to access the storage
        SharedPreferences sharedPreferences = getSharedPreferences("REGISTER_PAGE", MODE_PRIVATE);

        String storedUsername = sharedPreferences.getString(USERNAME_KEY, "DEFAULT VALUE");
        String storedPassword = sharedPreferences.getString(PASSWORD_KEY, "DEFAULT VALUE");

       if (getLoginUsername.equals(storedUsername) && getLoginPassword.equals(storedPassword)) {
           // direct the user to the next page if login attempt was successful
           Intent intent = new Intent(this, Dashboard.class);
           startActivity(intent);

        } else if(getLoginUsername.length() == 0) {
           Toast.makeText(this, "Please enter username", Toast.LENGTH_SHORT).show();

       } else if(getLoginPassword.length() == 0) {
           Toast.makeText(this, "Please enter password", Toast.LENGTH_SHORT).show();

       } else {
           // Toast indicating that login was unsuccessful
           editUsername.setText("");
           editPassword.setText("");
           Toast.makeText(this, "Authentication failed: Username or password incorrect", Toast.LENGTH_SHORT).show();
        }
    }

    // when the register button is clicked
    public void onBtnRegisterClick(View view) {
        // direct the user to the register page
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}