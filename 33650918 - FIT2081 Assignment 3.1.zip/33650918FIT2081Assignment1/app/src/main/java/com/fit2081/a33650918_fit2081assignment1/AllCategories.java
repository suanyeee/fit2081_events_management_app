package com.fit2081.a33650918_fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class AllCategories extends AppCompatActivity {

    FragmentManager fragmentManager;
    AllCategoriesFragment allCategoriesFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_categories);
        fragmentManager = getSupportFragmentManager();
        allCategoriesFragment = new AllCategoriesFragment();
    }
}