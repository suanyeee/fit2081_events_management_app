package com.fit2081.a33650918_fit2081assignment1.provider;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Categories.class, Events.class}, version = 2)
public abstract class CardDatabase extends RoomDatabase {

    // database name, this is important as data is contained inside a file named "card_database"
    public static final String CARD_DATABASE = "card_database";

    // reference to DAO, here RoomDatabase parent class will implement this interface
    public abstract CardDAO cardDAO();

    // marking the instance as volatile to ensure atomic access to the variable
    private static volatile CardDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    // ExecutorService is a JDK API that simplifies running tasks in asynchronous mode.
    // Generally speaking, ExecutorService automatically provides a pool of threads and an API
    // for assigning tasks to it.
    static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    /**
     * Since this class is an abstract class, to get the database reference we would need
     * to implement a way to get reference to the database.
     *
     * @param context Application of Activity Context
     * @return a reference to the database for read and write operation
     */
    static CardDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (CardDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    CardDatabase.class, CARD_DATABASE)
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}

