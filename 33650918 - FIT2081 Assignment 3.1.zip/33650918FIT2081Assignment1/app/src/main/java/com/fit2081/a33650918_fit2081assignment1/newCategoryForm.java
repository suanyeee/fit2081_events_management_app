package com.fit2081.a33650918_fit2081assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.fit2081.a33650918_fit2081assignment1.provider.CardViewModel;
import com.fit2081.a33650918_fit2081assignment1.provider.Categories;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class newCategoryForm extends AppCompatActivity {

    // declare constants for SharedPreferences key

    public static final String CATEGORY_ID_KEY = "categoryId_key";
    public static final String CATEGORY_NAME_KEY = "categoryName_key";
    public static final int EVENT_COUNT_KEY = 0;
    public static final boolean IS_ACTIVE_CAT_KEY = false;

    EditText editCategoryId;
    EditText editCategoryName;
    EditText editEventCount;
    Switch isActive;
    EditText editLocation;
    Categories categories;
    ArrayList<Categories> listCategories;
    private CardViewModel cardViewModel;
    MyRecyclerAdapter myRecyclerAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_category_form);

        // get reference from the user input
        editCategoryId = findViewById(R.id.editCategoryId3);
        editCategoryName = findViewById(R.id.editCategoryName);
        editEventCount = findViewById(R.id.editEventCount);
        isActive = findViewById(R.id.switchIsActive3);
        editLocation = findViewById(R.id.editLocation);

        // initialise ViewModel
        cardViewModel = new ViewModelProvider(this).get(CardViewModel.class);

        // sharedPreferences = getSharedPreferences("CATEGORY_FORM_PAGE", MODE_PRIVATE);

        /*ActivityCompat.requestPermissions(this, new String[]{
                android.Manifest.permission.SEND_SMS,
                android.Manifest.permission.RECEIVE_SMS,
                android.Manifest.permission.READ_SMS
        }, 0);

        MyBroadCastReceiver myBroadCastReceiver = new MyBroadCastReceiver();
        *//*
         * Register the broadcast handler with the intent filter that is declared in
         * class SMSReceiver @line 11
         * *//*
        registerReceiver(myBroadCastReceiver, new IntentFilter(CategorySMSReceiver.SMS_FILTER), RECEIVER_EXPORTED);*/

        // listCategories = new ArrayList<>();
        // listCategories = GsonSP.addCategoryToRecyclerView(this, "CATEGORY");
    }

    public void onBtnSaveCategoryClick(View view) {
        // change the user input into string
        String getCategoryId = editCategoryId.getText().toString();
        String getCategoryName = editCategoryName.getText().toString();
        String getEventCount = editEventCount.getText().toString();
        boolean isActiveBool = isActive.isChecked();
        String getLocation = editLocation.getText().toString();

        // if there is category name given, and no category id input from the user
        if (getCategoryName.length() > 0 && getCategoryId.length() == 0) {

            // if there is user input for event count
            if (getEventCount.length() > 0) {
                try {
                    // try convert the event count value into integer
                    int getEventCountInt = Integer.parseInt(getEventCount);

                    // if the event count given is greater than or equals to 0, or if there is no user input for event count
                    if (getEventCountInt >= 0) {

                        // create instance of Random class
                        Random random = new Random();
                        char firstRandomChar = (char) (random.nextInt(26) + 'A');
                        char secondRandomChar = (char) (random.nextInt(26) + 'A');
                        String fourRandomDigits = String.format("%04d", random.nextInt(10000));

                        // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                        String randomIdGenerator = "C" + firstRandomChar + secondRandomChar + "-" + fourRandomDigits;

                        // assign the generated random ID to the empty category id plaintext
                        editCategoryId.setText(randomIdGenerator);

                        // save the randomID, category name, event count and switch data to the storage
                        // saveMyData(randomIdGenerator, getCategoryName, getEventCountInt, isActiveBool);
                        // categories = new Categories(randomIdGenerator, getCategoryName, getEventCountInt, isActiveBool, getLocation);
                        // listCategories.add(categories);
//                      // GsonSP.saveCategoryListInSharedPreference(this, "CATEGORY KEY", listCategories);

                        // display a toast saying data saved successfully
                        String savedCategoryMsg = "Category saved successfully, " + randomIdGenerator;
                        Toast.makeText(this, savedCategoryMsg, Toast.LENGTH_SHORT).show();

                        Categories categories = new Categories(randomIdGenerator, getCategoryName, getEventCountInt, isActiveBool);
                        cardViewModel.insertCategory(categories);

                        startActivity(new Intent(this, Dashboard.class));


                        // if the user input a negative event count number
                    } else {
                        editEventCount.setText("");
                        Toast.makeText(this, "Please insert a positive number for event count.", Toast.LENGTH_SHORT).show();
                    }


                    // prevent app from crashing if user input of event count cannot be converted as string
                } catch (Exception e) {
                    editEventCount.setText("");
                    Toast.makeText(this, "Please insert a positive number for event count.", Toast.LENGTH_SHORT).show();
                }

                // if no event count value is given, assign the value 0
            } else {
                // create instance of Random class
                Random rnd = new Random();
                char firstRandomChar = (char) (rnd.nextInt(26) + 'A');
                char secondRandomChar = (char) (rnd.nextInt(26) + 'A');
                String fourRandomDigits = String.format("%04d", rnd.nextInt(10000));

                // convert the random ID into string the moment it has been done, so that it can be standardised in the plaintext and toast
                String randomIdGenerator = "C" + firstRandomChar + secondRandomChar + "-" + fourRandomDigits;

                // assign the generated random ID to the empty category id plaintext
                editCategoryId.setText(randomIdGenerator);

                // save the randomID, category name, event count and switch data to the storage
                // saveMyData(randomIdGenerator, getCategoryName, 0, isActiveBool);
                // categories = new Categories(randomIdGenerator, getCategoryName, 0, isActiveBool, getLocation);
                // listCategories.add(categories);
                // GsonSP.saveCategoryListInSharedPreference(this, "CATEGORY KEY", listCategories);

                // display a toast saying data saved successfully
                String savedCategoryMsg = "Category saved successfully, " + randomIdGenerator;
                Toast.makeText(this, savedCategoryMsg, Toast.LENGTH_SHORT).show();

                Categories categories = new Categories(randomIdGenerator, getCategoryName, 0, isActiveBool);
                cardViewModel.insertCategory(categories);

                startActivity(new Intent(this, Dashboard.class));
            }

            // if there is user input for category id, which shouldn't happen
        } else if(getCategoryId.length() > 0) {

            // assign empty values to the category id
            editCategoryId.setText("");
            Toast.makeText(this, "Please leave the category ID empty, it is auto generated.", Toast.LENGTH_SHORT).show();

            // if no category name was given
        } else {
            Toast.makeText(this, "Please enter a category name", Toast.LENGTH_SHORT).show();
        }
    }

/*    private void saveMyData(String categoryIdValue, String categoryNameValue, int eventCountValue, boolean isActiveOrNot) {
        // initialise shared preference class variable to access the storage
        SharedPreferences sharedPreferences = getSharedPreferences("CATEGORY_FORM_PAGE", MODE_PRIVATE);

        // use .edit function to access file using Editor variable
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // save key-value pairs to the shared preference file
        editor.putString(CATEGORY_ID_KEY, categoryIdValue);
        editor.putString(CATEGORY_NAME_KEY, categoryNameValue);
        editor.putInt(String.valueOf(EVENT_COUNT_KEY), eventCountValue);
        editor.putBoolean(String.valueOf(IS_ACTIVE_CAT_KEY), isActiveOrNot);

        // save data asynchronously without freezing the UI
        editor.apply();
    }*/

    /*class MyBroadCastReceiver extends BroadcastReceiver {
        *//*
         * This method 'onReceive' will get executed every time class SMSReceive sends a broadcast
         * *//*
        @Override
        public void onReceive(Context context, Intent intent) {
            // Tokenize received message here
            *//*
             * Retrieve the message from the intent
             * *//*
            String msg = intent.getStringExtra(CategorySMSReceiver.SMS_MSG_KEY);
            myStringTokenizer(msg);
        }

        public void myStringTokenizer(String msg) {
            try {
                *//*
                 * String Tokenizer is used to parse the incoming message
                 * The protocol is to have the account holder name and account number separate by a semicolon
                 * *//*
                StringTokenizer sT = new StringTokenizer(msg, ";");
                String categoryNameStr = sT.nextToken();
                String eventCountStr = sT.nextToken();
                String isActiveStr = sT.nextToken();

                // if the sms input starts with "category:"
                if (categoryNameStr.startsWith("category:")) {
                    categoryNameStr = categoryNameStr.substring("category:".length()).trim();

                    editCategoryName.setText(categoryNameStr);
                    int eventCountInt = Integer.parseInt(eventCountStr);
                    editEventCount.setText(String.valueOf(eventCountInt));
                    isActive.setChecked(isActiveStr.equals("TRUE"));

                    // if switch input is "TRUE", proceed
                    if (isActiveStr.equals("TRUE")) {
                        Toast.makeText(newCategoryForm.this, "Message Imported Successfully.", Toast.LENGTH_SHORT).show();

                    // if switch input is "FALSE", proceed
                    } else if (isActiveStr.equals("FALSE")) {
                        Toast.makeText(newCategoryForm.this, "Message Imported Successfully.", Toast.LENGTH_SHORT).show();

                    // other switch inputs will not be allowed, reset all values to default values
                    } else {
                        editCategoryName.setText("");
                        editEventCount.setText("");
                        isActive.setChecked(false);
                        Toast.makeText(newCategoryForm.this, "Invalid response, unable to read category form details.", Toast.LENGTH_SHORT).show();
                    }

                // if sms input does not start with "category:"
                } else {
                    editCategoryName.setText("");
                    editEventCount.setText("");
                    isActive.setChecked(false);
                    Toast.makeText(newCategoryForm.this, "Invalid response, unable to read category form details.", Toast.LENGTH_SHORT).show();
                }

                } catch(Exception e){
                    editCategoryName.setText("");
                    editEventCount.setText("");
                    isActive.setChecked(false);
                    Toast.makeText(newCategoryForm.this, "Invalid response, unable to read category form details.", Toast.LENGTH_SHORT).show();
                }
            }
        }*/
    }