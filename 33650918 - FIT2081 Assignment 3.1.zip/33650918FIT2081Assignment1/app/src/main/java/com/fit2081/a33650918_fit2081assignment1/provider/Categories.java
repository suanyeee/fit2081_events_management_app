package com.fit2081.a33650918_fit2081assignment1.provider;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "categories")
public class Categories {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    @NonNull
    private int id;

    @ColumnInfo(name = "columnCategoryId")
    private String category_id;

    @ColumnInfo(name = "columnCategoryName")
    private String category_name;

   /* @ColumnInfo(name = "columnLocation")
    private String location;*/

    @ColumnInfo(name = "columnEventCount")
    private int event_count;

    @ColumnInfo(name = "columnIsActiveCat")
    private boolean is_active_cat;



    public Categories(String category_id, String category_name, int event_count, boolean is_active_cat) {
        this.category_id = category_id;
        this.category_name = category_name;
        // this.location = location;
        this.event_count = event_count;
        this.is_active_cat = is_active_cat;

    }

    public String getCategory_id() {
        return category_id;
    }

    public String getCategory_name() {
        return category_name;
    }

    // public String getLocation() { return location; }

    public int getEvent_count() {
        return event_count;
    }

    public boolean isIs_active_cat() {
        return is_active_cat;
    }


    public int getId() {
        return id;
    }

    public void setId(@NonNull int id) {
        this.id = id;
    }
}

